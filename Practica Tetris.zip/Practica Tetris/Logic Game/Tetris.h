#ifndef TETRIS_H
#define TETRIS_H
#include <stdio.h>
#include <string>
#include "Partida.h"
#include "Joc.h"
#include "Tauler.h"
#include "Figura.h"
using namespace std;

typedef enum
{
	MENU = 0,
	PUNTUACIONS,
	PARTIDA,
	POST_PARTIDA
} Pantalla;

class Tetris
{
public:
	Tetris();
	void afegeixPuntuacio(const string& nom, int punts);
	bool actualitza(double deltaTime);
private:
	Partida m_partida;
	Pantalla m_pantalla;
	int m_cursor;
	string m_noms[10];
	int m_puntuacions[10];
};
#endif