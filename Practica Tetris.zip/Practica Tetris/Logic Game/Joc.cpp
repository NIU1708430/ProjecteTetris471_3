#include "Joc.h"

ifstream& operator>> (ifstream& input, queue<Figura>& cua)
{
    Figura figura;
    while (!input.eof())
    {
        input >> figura;
        cua.push(figura);
    }
    return input;
}

TipusFigura Joc::figuraRand()
{
    srand(time(NULL));
    int nFigura = (rand() % 7);
    TipusFigura figura;
    switch (nFigura)
    {
    case 0:
        figura = FIGURA_O;
        break;
    case 1:
        figura = FIGURA_I;
        break;
    case 2:
        figura = FIGURA_T;
        break;
    case 3:
        figura = FIGURA_L;
        break;
    case 4:
        figura = FIGURA_J;
        break;
    case 5:
        figura = FIGURA_Z;
        break;
    case 6:
        figura = FIGURA_S;
        break;
    }
    return figura;
}

void Joc::dibuixa()
{
    IMAGE_NAME graficFigura;

    GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
    GraphicManager::getInstance()->drawSprite(GRAFIC_TAULER, POS_X_TAULER, POS_Y_TAULER, false);

    m_tauler.dibuixa();
    m_figura.dibuixa();

    if (m_cuaFigures.empty())
        GraphicManager::getInstance()->drawSprite(GRAFIC_NO_FIGURA, POS_X_TAULER + 341, POS_Y_TAULER, false);
    else
    {
        switch (m_cuaFigures.front().getFigura())
        {
        case FIGURA_O:
            graficFigura = GRAFIC_FIGURA_O;
            break;
        case FIGURA_I:
            graficFigura = GRAFIC_FIGURA_I;
            break;
        case FIGURA_T:
            graficFigura = GRAFIC_FIGURA_T;
            break;
        case FIGURA_L:
            graficFigura = GRAFIC_FIGURA_L;
            break;
        case FIGURA_J:
            graficFigura = GRAFIC_FIGURA_J;
            break;
        case FIGURA_Z:
            graficFigura = GRAFIC_FIGURA_Z;
            break;
        case FIGURA_S:
            graficFigura = GRAFIC_FIGURA_S;
            break;
        }
        GraphicManager::getInstance()->drawSprite(graficFigura, POS_X_TAULER + 341, POS_Y_TAULER, false);
    }

    switch (m_figuraGuardada.getFigura())
    {
    case FIGURA_O:
        graficFigura = GRAFIC_FIGURA_O;
        break;
    case FIGURA_I:
        graficFigura = GRAFIC_FIGURA_I;
        break;
    case FIGURA_T:
        graficFigura = GRAFIC_FIGURA_T;
        break;
    case FIGURA_L:
        graficFigura = GRAFIC_FIGURA_L;
        break;
    case FIGURA_J:
        graficFigura = GRAFIC_FIGURA_J;
        break;
    case FIGURA_Z:
        graficFigura = GRAFIC_FIGURA_Z;
        break;
    case FIGURA_S:
        graficFigura = GRAFIC_FIGURA_S;
        break;
    case NO_FIGURA:
        graficFigura = GRAFIC_NO_FIGURA;
        break;
    }
    GraphicManager::getInstance()->drawSprite(graficFigura, POS_X_TAULER + 341, POS_Y_TAULER + 150, false);
}

void Joc::inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures)
{
    ifstream input;
    if (mode == 1)
    {  
        input.open(fitxerInicial);
        if (input.is_open())
            input >> m_figura >> m_tauler;
        input.close();

        input.open(fitxerFigures);
        if (input.is_open())
            input >> m_cuaFigures;
        input.close();
    }
    else
    {
        input.open("./data/Games/blank.txt");
        if (input.is_open())
        {
            m_figura.inicialitza(figuraRand(), 0, 5, 0);
            input >> m_tauler;
        }
        input.close();
    }
    input.close();

    m_figuraGuardada.inicialitza(NO_FIGURA, 0, 5, 0);
    m_guardatDisponible = true;
}

void Joc::guardaFigura()
{
    if (m_guardatDisponible)
    {
        if (m_figuraGuardada.getFigura() == NO_FIGURA)
        {
            m_figuraGuardada.inicialitza(m_figura.getFigura(), 0, 5, 0);
            m_figura.inicialitza(m_cuaFigures.front().getFigura(), 0, 5, 0);
            m_cuaFigures.pop();
        }
        else
        {
            Figura figuraAux;
            figuraAux = m_figuraGuardada;
            m_figuraGuardada.inicialitza(m_figura.getFigura(), 0, 5, 0);
            m_figura.inicialitza(figuraAux.getFigura(), 0, 5, 0);
        }
        m_guardatDisponible = false;
    }
}

bool Joc::giraFigura(DireccioGir direccio)
{
    bool gir = true;
    
    if (direccio == GIR_HORARI)
    {
        m_figura.girHorari();
        if(m_tauler.colisio(m_figura))
        {
            m_figura.girAntihorari();
            gir = false;
        }
    }
    else
    {
        m_figura.girAntihorari();
        if (m_tauler.colisio(m_figura))
        {
            m_figura.girHorari();
            gir = false;
        }
    }
    
    return gir;
}

bool Joc::mouFigura(int dirX)
{
    bool mov = true;
    
    if (dirX > 0)
    {
        m_figura.movDreta();
        if (m_tauler.colisio(m_figura))
        {
            m_figura.movEsquerra();
            mov = false;
        }
    }
    else
    {
        m_figura.movEsquerra();
        if (m_tauler.colisio(m_figura))
        {
            m_figura.movDreta();
            mov = false;
        }
    }
    
    return mov;
}

int Joc::baixaFigura(int mode)
{
    int nFilesCompletes = 0;

    m_figura.baixa();

    if (m_tauler.colisio(m_figura))
    {
        m_figura.puja();

        if (m_figura.getFila() <= 0)
        {
            nFilesCompletes = -2;
        }
        else
        {
            //La figura ja est� al seu lloc final i s'afegeix al tauler de forma definitiva
            int i = m_figura.getFila() - 1, j = m_figura.getColumna() - 1;
            for (int y = m_figura.getOffset(0); y < m_figura.getLongCostat() - m_figura.getOffset(2); y++)
                for (int x = m_figura.getOffset(3); x < m_figura.getLongCostat() - m_figura.getOffset(1); x++)
                    if (m_figura.getBloc(y, x) != NO_COLOR)
                        m_tauler.setBloc(i + y, j + x, m_figura.getBloc(y, x));
    
            //S'esborra la figura ara que �s part del tauler per evitar que surti duplicada al utilitzar la funci� escriuTauler
            m_figura.inicialitza(NO_FIGURA, m_figura.getFila(), m_figura.getColumna(), 0);
    
            //Es comprova si hi ha alguna fila completa i, en cas d'haver-hi, s'elimina i s'afegeix un punt
            bool filaCompleta = true;
            for (i = 0; i < N_FILES_TAULER; i++)
            {
                filaCompleta = true;
                j = 0;
                while (j < N_COL_TAULER && filaCompleta)
                {
                    if (m_tauler.getBloc(i, j) == COLOR_NEGRE)
                        filaCompleta = false;
                    j++;
                }
                if (filaCompleta)
                {
                    for (int y = i; y > 0; y--)
                        for (int x = 0; x < N_COL_TAULER; x++)
                            m_tauler.setBloc(y, x, m_tauler.getBloc(y - 1, x));
                    for (int x = 0; x < N_COL_TAULER; x++)
                        m_tauler.setBloc(0, x, COLOR_NEGRE);
                    nFilesCompletes++;
                }
            }
            if (nFilesCompletes == 0)
                nFilesCompletes = -1;
        }
        if (!m_cuaFigures.empty())
        {
            m_figura = m_cuaFigures.front();
            m_cuaFigures.pop();
        }
        else
            nFilesCompletes = -2;
        m_guardatDisponible = true;
    }

    Figura figuraNova;
    figuraNova.inicialitza(figuraRand(), 0, 5, 0);
    if (mode == 0)
    {
        if (m_cuaFigures.size() > 2)
        {
            if (m_cuaFigures.size() < 10 && figuraNova.getFigura() != m_cuaFigures.back().getFigura())
                m_cuaFigures.push(figuraNova);
        }
        else
            m_cuaFigures.push(figuraNova);
    }
    return nFilesCompletes;
}

int Joc::baixaInst(int mode)
{
    int nFilesCompletes = 0;
    do
    {
        nFilesCompletes = baixaFigura(mode);
    } while (nFilesCompletes == 0);

    return nFilesCompletes;
}

void Joc::escriuTauler(const string& nomFitxer)
{
    //Es crea una c�pia del tauler per no imprimir la figura al real
    ColorFigura tauler[N_FILES_TAULER][N_COL_TAULER];
    m_tauler.getTauler(tauler);

    //S'afegeix la figura al tauler fals per tal que aparegui al fitxer
    int i = m_figura.getFila() - 1, j = m_figura.getColumna() - 1;
    for (int y = m_figura.getOffset(0); y < m_figura.getLongCostat() - m_figura.getOffset(2); y++)
        for (int x = m_figura.getOffset(3); x < m_figura.getLongCostat() - m_figura.getOffset(1); x++)
            if (m_figura.getBloc(y, x) != NO_COLOR)
                tauler[i + y][j + x] = m_figura.getBloc(y, x);

    ofstream output;
    output.open(nomFitxer);
    if (output.is_open())
    {
        for (int i = 0; i < N_FILES_TAULER; i++)
        {
            for (int j = 0; j < N_COL_TAULER; j++)
                output << tauler[i][j] << " ";
            output << endl;
        }
        output.close();
    }
}
