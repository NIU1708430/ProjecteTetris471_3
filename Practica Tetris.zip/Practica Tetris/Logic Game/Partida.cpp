#include "Partida.h"
#include "GraphicManager.h"

ifstream& operator>> (ifstream& input, queue<int>& cua)
{
    int moviment;
    while (!input.eof())
    {
        input >> moviment;
        cua.push(moviment);
    }
    return input;
}

Partida::Partida()
{
    m_temps = 0;
    m_punts = 0;
    m_nivell = 0;
    m_mode = 0;
}

void Partida::inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments)
{
    m_punts = 0;
    m_temps = 0;
    m_nivell = 0;
    m_mode = mode;
    if (m_mode == 1)
    {
        ifstream input;
        input.open(fitxerMoviments);
        if (input.is_open())
            input >> m_cuaMoviments;
        input.close();
    }
    m_joc.inicialitza(m_mode, fitxerInicial, fitxerFigures);
}

bool Partida::sumaPunts(int nFilesCompletes)
{
    bool continuar = true;
    switch (nFilesCompletes)
    {
    case -1:
        m_punts += 10;
        break;
    case 1:
        m_punts += 110;
        break;
    case 2:
        m_punts += 260;
        break;
    case 3:
        m_punts += 385;
        break;
    case 4:
        m_punts += 510;
        break;
    case -2:
        continuar = false;
        break;
    }
    return continuar;
}

bool Partida::actualitza(double deltaTime)
{
    int nFilesCompletes;
    bool continuar = true;
    m_joc.dibuixa();
    GraphicManager::getInstance()->drawFont(FONT_GREEN_30, POS_X_TAULER, POS_Y_TAULER - 50, 1.0, "Punts: " + to_string(m_punts));

    if (m_punts > 3000)
        m_nivell = 3;
    else if (m_punts > 2000)
        m_nivell = 2;
    else if (m_punts > 1000)
        m_nivell = 1;

    m_temps += deltaTime;
    if (m_mode == 0)
    {
        if (Keyboard_GetKeyTrg(KEYBOARD_RIGHT) || Keyboard_GetKeyTrg(KEYBOARD_D))
            m_joc.mouFigura(1);
        if (Keyboard_GetKeyTrg(KEYBOARD_LEFT) || Keyboard_GetKeyTrg(KEYBOARD_A))
            m_joc.mouFigura(-1);
        if (Keyboard_GetKeyTrg(KEYBOARD_DOWN) || Keyboard_GetKeyTrg(KEYBOARD_S))
        {
            nFilesCompletes = m_joc.baixaFigura(m_mode);
            continuar = sumaPunts(nFilesCompletes);
        }
        if (Keyboard_GetKeyTrg(KEYBOARD_E) || Keyboard_GetKeyTrg(KEYBOARD_KEYPAD_0))
            m_joc.giraFigura(GIR_HORARI);
        if (Keyboard_GetKeyTrg(KEYBOARD_Q) || Keyboard_GetKeyTrg(KEYBOARD_RCTRL))
            m_joc.giraFigura(GIR_ANTI_HORARI);
        if (Keyboard_GetKeyTrg(KEYBOARD_F) || Keyboard_GetKeyTrg(KEYBOARD_RSHIFT))
        {
            nFilesCompletes = m_joc.baixaInst(m_mode);
            continuar = sumaPunts(nFilesCompletes);
        }
        if (Keyboard_GetKeyTrg(KEYBOARD_R) || Keyboard_GetKeyTrg(KEYBOARD_R))
            m_joc.guardaFigura();
    }
    if (m_temps > 1 - 0.25 * m_nivell)
    {
        if (m_mode == 1 && !m_cuaMoviments.empty())
        {
            switch (m_cuaMoviments.front())
            {
            case 0:
                m_joc.mouFigura(-1);
                break;
            case 1:
                m_joc.mouFigura(1);
                break;
            case 2:
                m_joc.giraFigura(GIR_HORARI);
                break;
            case 3:
                m_joc.giraFigura(GIR_ANTI_HORARI);
                break;
            case 4:
                nFilesCompletes = m_joc.baixaFigura(m_mode);
                continuar = sumaPunts(nFilesCompletes);
                break;
            case 5:
                nFilesCompletes = m_joc.baixaInst(m_mode);
                continuar = sumaPunts(nFilesCompletes);
                break;
            case 6:
                m_joc.guardaFigura();
            }
            m_cuaMoviments.pop();
        }
        else
        {
            if (m_mode == 0)
            {
                nFilesCompletes = m_joc.baixaFigura(m_mode);
                continuar = sumaPunts(nFilesCompletes);
            }
            else
            {
                continuar = false;
            }
        }
        m_temps = 0.0;
    }
    

    return continuar;
}

