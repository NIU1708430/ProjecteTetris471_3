#include "Tetris.h"
#include <iostream>

Tetris::Tetris()
{
	m_pantalla = MENU;
	m_cursor = 0;
	for (int i = 0; i < 10; i++)
	{
		m_noms[i] = "";
		m_puntuacions[i] = 0;
	}
	
	ifstream archiuPunts, archiuNoms;
	archiuPunts.open("./data/puntuacions.txt");
	archiuNoms.open("./data/noms.txt");
	if (archiuPunts.is_open() && archiuNoms.is_open())
	{
		int i = 0;
		while (!archiuPunts.eof() && !archiuNoms.eof() && i < 10)
		{
			archiuNoms >> m_noms[i];
			archiuPunts >> m_puntuacions[i];
			i++;
		}
		archiuPunts.close();
		archiuNoms.close();
	}
}

void Tetris::afegeixPuntuacio(const string& nom, int punts)
{
	bool trobat = false;
	int i = 9;

	while (i >= 0 && !trobat)
		if (punts < m_puntuacions[i])
			trobat = true;
		else
			i--;

	if (i != 9)
	{
		for (int j = 9; j > i + 1; j--)
		{
			m_noms[j] = m_noms[j - 1];
			m_puntuacions[j] = m_puntuacions[j - 1];
		}
		m_noms[i + 1] = nom;
		m_puntuacions[i + 1] = punts;
	}

}

bool Tetris::actualitza(double deltaTime)
{
	bool partidaEnCurs;
	bool continuar = true;
	if (m_pantalla == PARTIDA)
	{
		partidaEnCurs = m_partida.actualitza(deltaTime);
		if (!partidaEnCurs)
		{
			if (m_partida.getMode() == 0)
				m_pantalla = POST_PARTIDA;
			else
				m_pantalla = MENU;
		}

	}
	if (m_pantalla == MENU)
	{
		GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
		GraphicManager::getInstance()->drawSprite(GRAFIC_MENU, 0, 0, false);

		switch (m_cursor)
		{
		case 0:
			GraphicManager::getInstance()->drawSprite(GRAFIC_FLETXA, 98, 309, false);
			break;
		case 1:
			GraphicManager::getInstance()->drawSprite(GRAFIC_FLETXA, 129, 399, false);
			break;
		case 2:
			GraphicManager::getInstance()->drawSprite(GRAFIC_FLETXA, 98, 489, false);
			break;
		case 3:
			GraphicManager::getInstance()->drawSprite(GRAFIC_FLETXA, 175, 579, false);
			break;
		}
		
		if (Keyboard_GetKeyTrg(KEYBOARD_DOWN) || Keyboard_GetKeyTrg(KEYBOARD_S))
		{
			m_cursor++;
			if (m_cursor == 4)
				m_cursor = 0;
		}
		if (Keyboard_GetKeyTrg(KEYBOARD_UP) || Keyboard_GetKeyTrg(KEYBOARD_W))
		{
			m_cursor--;
			if (m_cursor == -1)
				m_cursor = 3;
		}
		if (Keyboard_GetKeyTrg(KEYBOARD_SPACE))
		{
			switch (m_cursor)
			{
			case 0:
				m_partida.inicialitza(0, "./data/Games/partida.txt", "./data/Games/figures.txt", "./data/Games/moviments.txt");
				m_pantalla = PARTIDA;
				break;
			case 1:
				m_partida.inicialitza(1, "./data/Games/partida.txt", "./data/Games/figures.txt", "./data/Games/moviments.txt");
				m_pantalla = PARTIDA;
				break;
			case 2:
				m_pantalla = PUNTUACIONS;
				break;
			case 3:
				continuar = false;
				break;
			}
		}
	}
	if (m_pantalla == PUNTUACIONS)
	{
		int i = 0;
		GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
		GraphicManager::getInstance()->drawSprite(GRAFIC_PUNTUACIONS, 0, 0, false);
		while (i < 10 && m_noms[i] != "")
		{
			GraphicManager::getInstance()->drawFont(FONT_BLACK_30, 50, 250 + 30 * i, 1.0, to_string(i + 1) + ". " + m_noms[i] + ": " + to_string(m_puntuacions[i]));
			i++;
		}
		if (Keyboard_GetKeyTrg(KEYBOARD_LCTRL))
			m_pantalla = MENU;
	}
	if (m_pantalla == POST_PARTIDA)
	{
		string nomJugador;
		GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
		GraphicManager::getInstance()->drawSprite(GRAFIC_POST_PARTIDA, 0, 0, false);
		GraphicManager::getInstance()->drawFont(FONT_BLACK_30, 120, 200, 1.5, "PUNTUACIO: " + to_string(m_partida.getPunts()));
		if (Keyboard_GetKeyTrg(KEYBOARD_SPACE))
		{
			cout << "Escriu el teu nom: " << endl;
			cin >> nomJugador;
			if (nomJugador != "")
				afegeixPuntuacio(nomJugador, m_partida.getPunts());

			ofstream archiuPunts, archiuNoms;
			archiuPunts.open("./data/puntuacions.txt");
			archiuNoms.open("./data/noms.txt");
			if (archiuPunts.is_open() && archiuNoms.is_open())
			{
				int i = 0;
				while (m_noms[i] != "" && i < 10)
				{
					archiuNoms << m_noms[i] << endl;
					archiuPunts << m_puntuacions[i] << endl;
					i++;
				}
				archiuPunts.close();
				archiuNoms.close();
			}

			m_pantalla = MENU;
		}
	}
	return continuar;
}