#ifndef PARTIDA_H
#define PARTIDA_H

#include <stdio.h>
#include <queue>
#include <string>
#include "InfoJoc.h"
#include "Joc.h"
#include "Tauler.h"
#include "Figura.h"

using namespace std;

class Partida 
{
public:
    Partida();
    bool sumaPunts(int nFilesCompletes);
    void inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments);
    bool actualitza(double deltaTime);
    int getPunts() const { return m_punts; }
    int getMode() const { return  m_mode; }
private:
    double m_temps;
    Joc m_joc;
    int m_punts;
    int m_nivell;
    int m_mode;
    queue<int> m_cuaMoviments;
};

ifstream& operator>> (ifstream& input, queue<int>& cua);

#endif 
