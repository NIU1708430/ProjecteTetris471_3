#ifndef TAULER_H
#define TAULER_H
#include "Figura.h"

class Tauler
{
public:
    IMAGE_NAME colorToSprite(ColorFigura color);
    void dibuixa();
    void getTauler(ColorFigura tauler[N_FILES_TAULER][N_COL_TAULER]) const;
    bool colisio(const Figura& figura);
    void inicialitza(const ColorFigura tauler[N_FILES_TAULER][N_COL_TAULER]);
    void setBloc(int i, int j, ColorFigura color) { m_tauler[i][j] = color; }
    ColorFigura getBloc(int i, int j) const { return m_tauler[i][j]; }
private:
    ColorFigura m_tauler[N_FILES_TAULER][N_COL_TAULER];
};

ifstream& operator>> (ifstream& input, ColorFigura& tile);
ifstream& operator>> (ifstream& input, Tauler& tauler);

#endif