#ifndef JOC_H
#define JOC_H
#include "Tauler.h"
#include "Figura.h"
#include <string>
#include <queue>
using namespace std;

class Joc
{
public:
	Joc() {}
	TipusFigura figuraRand();
	void dibuixa();
	void inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures);
	void guardaFigura();
	bool giraFigura(DireccioGir direccio);
	bool mouFigura(int dirX);
	int baixaFigura(int mode);
	int baixaInst(int mode);
	void escriuTauler(const string& nomFitxer);
private:
    Tauler m_tauler;
    Figura m_figura;
	Figura m_figuraGuardada;
	bool m_guardatDisponible;
	queue<Figura> m_cuaFigures;
};

ifstream& operator>> (ifstream& input, queue<Figura>& cua);
#endif