#include "Tauler.h"

ifstream& operator>> (ifstream& input, ColorFigura& tile)
{
    int intTile;
    input >> intTile;
    switch (intTile)
    {
        case 0:
            tile = COLOR_NEGRE;
            break;
        case 1 :
            tile = COLOR_GROC;
            break;
        case 2 :
            tile = COLOR_BLAUCEL;
            break;
        case 3 :
            tile = COLOR_MAGENTA;
            break;
        case 4 :
            tile = COLOR_TARONJA;
            break;
        case 5 :
            tile = COLOR_BLAUFOSC;
            break;
        case 6 :
            tile = COLOR_VERMELL;
            break;
        case 7 :
            tile = COLOR_VERD;
            break;
        default :
            tile = NO_COLOR;
            break;
    }
    return input;
}

ifstream& operator>> (ifstream& input, Tauler& tauler)
{
    ColorFigura grid[N_FILES_TAULER][N_COL_TAULER];

    for (int i = 0; i < N_FILES_TAULER; i++)
        for (int j = 0; j < N_COL_TAULER; j++)
            input >> grid[i][j];

    tauler.inicialitza(grid);
    return input;
}

IMAGE_NAME Tauler::colorToSprite(ColorFigura color)
{
    IMAGE_NAME sprite;
    switch (color)
    {
    case 1:
        sprite = GRAFIC_QUADRAT_GROC;
        break;
    case 2:
        sprite = GRAFIC_QUADRAT_BLAUCEL;
        break;
    case 3:
        sprite = GRAFIC_QUADRAT_MAGENTA;
        break;
    case 4:
        sprite = GRAFIC_QUADRAT_TARONJA;
        break;
    case 5:
        sprite = GRAFIC_QUADRAT_BLAUFOSC;
        break;
    case 6:
        sprite = GRAFIC_QUADRAT_VERMELL;
        break;
    case 7:
        sprite = GRAFIC_QUADRAT_VERD;
        break;
    }
    return sprite;
}

void Tauler::dibuixa()
{
    for (int i = 0; i < N_FILES_TAULER; i++)
        for (int j = 0; j < N_COL_TAULER; j++)
            if (m_tauler[i][j] != COLOR_NEGRE)
            {
                IMAGE_NAME sprite = colorToSprite(m_tauler[i][j]);
                GraphicManager::getInstance()->drawSprite(sprite, POS_X_TAULER + ((j + 1) * MIDA_QUADRAT), POS_Y_TAULER + (i * MIDA_QUADRAT) + 2, false);
            }
}

void Tauler::inicialitza(const ColorFigura tauler[N_FILES_TAULER][N_COL_TAULER])
{
    for (int i = 0; i < N_FILES_TAULER; i++)
        for (int j = 0; j < N_COL_TAULER; j++)
            m_tauler[i][j] = tauler[i][j];
}

void Tauler::getTauler(ColorFigura tauler[N_FILES_TAULER][N_COL_TAULER]) const
{
    for (int i = 0; i < N_FILES_TAULER; i++)
        for (int j = 0; j < N_COL_TAULER; j++)
            tauler[i][j] = m_tauler[i][j];
}

bool Tauler::colisio(const Figura& figura)
{
    int i = figura.getFila() - 1, j = figura.getColumna() - 1;
    bool choca = false;
    
    //Es comprova que la figura no surti del tauler
    if (i < 0 - figura.getOffset(0) || j < 0 - figura.getOffset(3) ||
        i + figura.getLongCostat() - figura.getOffset(2) > N_FILES_TAULER || j + figura.getLongCostat() - figura.getOffset(1) > N_COL_TAULER)
        choca = true;
    
    //Es comprova que la figura no es fusioni amb altres blocs del tauler
    int x = figura.getOffset(3), y = figura.getOffset(0);
    while (!choca && y < figura.getLongCostat() - figura.getOffset(2))
    {
        while (!choca && x < figura.getLongCostat() - figura.getOffset(1))
        {
            if (figura.getBloc(y, x) != NO_COLOR && m_tauler[i + y][j + x] != COLOR_NEGRE)
                choca = true;
            x++;
        }
        x = 0;
        y++;
    }
    
    return choca;
}
